package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import application.Main;
import dao.DBConnect;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminLoginController {

    @FXML
    private Button btnBack;

    @FXML
    private Button btnSignin;
 
    @FXML
    private ImageView imgadmin;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private TextField txtUsername;

    @FXML
    private AnchorPane mainPane;
    

    private Stage adminLoginStage; // Reference to the admin login window stage

    public void setAdminLoginStage(Stage stage) {
        this.adminLoginStage = stage;
    }
    @FXML
    public void backToHome(ActionEvent event) {
        try {
            // Your existing code for loading Home.fxml
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/Home.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.setScene(scene);
            currentStage.setTitle("Home");
            currentStage.show();

            // Check if adminLoginStage is not null before closing
            if (adminLoginStage != null) {
                adminLoginStage.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void SignIn(ActionEvent event) {
    	String username = txtUsername.getText();
        String password = txtPassword.getText();

        if (authenticateUser(username, password)) {
        	openAdminHome(adminLoginStage); // Pass the adminLoginStage reference
        } else {
            // Handle invalid login credentials
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Authentication Error");
            alert.setHeaderText(null);
            alert.setContentText("Invaild Credentials. Please try again.");
            alert.showAndWait();
            
        }
    }
    
    private boolean authenticateUser(String username, String password) {
        try {
            Connection connection = new DBConnect().connect();
            String sql = "SELECT * FROM olympiad_admin WHERE username = ? AND password = ? limit 1";
            PreparedStatement preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next(); // Returns true if there's a matching record, false otherwise

        } catch (SQLException se) {
            se.printStackTrace();
            return false;
        }
    }

    public void openAdminHome (Stage adminLoginStage){
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/AdminHome.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Stage adminHomeStage = new Stage();
            adminHomeStage.setTitle("Admin Home");
            adminHomeStage.setScene(scene);
            adminHomeStage.show();

            if (adminLoginStage != null) {
                adminLoginStage.close(); // Close the Admin Login window when opening Admin Home
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}   