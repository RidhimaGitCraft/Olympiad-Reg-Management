package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Olympiad;
import models.User;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import application.Main;
import dao.DBConnect;

public class OlympiadRegController {

	@FXML
	private Button btnback;

	@FXML
	private TableColumn<Olympiad, LocalDate> DeadlineColumn;

	@FXML
	private TableColumn<Olympiad, LocalDate> ExamDateColumn;

	@FXML
	private TableColumn<Olympiad, Integer> IDColumn;

	@FXML
	private TableColumn<Olympiad, String> OlympiadNameColumn;

	@FXML
	private TableColumn<Olympiad, Float> PriceColumn;

	@FXML
	private TableColumn<Olympiad, String> RegisteredColumn;

	@FXML
	private TableView<Olympiad> table;

	@FXML
	private TextField txtOlympiad;

	@FXML
	void Back(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/StudentPortal.fxml"));
			Parent parent = loader.load();

			// Get the stage from the current button
			Stage stage = (Stage) btnback.getScene().getWindow();
			Scene scene = new Scene(parent);
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
		
	@FXML
	void Payment(ActionEvent event) {
		// Logic to handle the payment action

		if (checkPreviousEnroll()) {

			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Alert");
			alert.setHeaderText("Alert");
			alert.setContentText("Enrollment already exists");
			alert.showAndWait();

		} else {
			enrollUser();
			initialize();
		}
		

	}

	boolean checkPreviousEnroll() {

		try {
			User user = Main.getCurrentUser();
			Connection connection = new DBConnect().connect();
			String sql = "select * from olympiad_reg where olympiad_reg.student_id = ? And olympiad_reg.olympiad_id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, user.getID());
			preparedStatement.setString(2, txtOlympiad.getText());
			ResultSet rowsAffected = preparedStatement.executeQuery();

			return rowsAffected.next();

		} catch (SQLException se) {
			se.printStackTrace();
			return false;
		}
	}

	boolean checkOlympiadStatus() {
		try {
			Connection connection = new DBConnect().connect();
			String sql = "select * from olympiad_olympiad where id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, txtOlympiad.getText());

			ResultSet rowsAffected = preparedStatement.executeQuery();

			return rowsAffected.next();

		} catch (SQLException se) {
			se.printStackTrace();
			return false;
		}
	}

	void enrollUser() {
		if (checkOlympiadStatus()) {
			User user = Main.getCurrentUser();
			try {
				Connection connection = new DBConnect().connect();
				String sql = "Insert Into olympiad_reg (student_id,olympiad_id) values (?,?)";
				PreparedStatement preparedStatement = connection.prepareStatement(sql);

				preparedStatement.setInt(1, user.getID());
				preparedStatement.setString(2, txtOlympiad.getText());

				preparedStatement.executeUpdate();

				Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
				alert.setTitle("Succesfully Registered");
				alert.setHeaderText("Success");
				alert.setContentText("Successfully Registered for Olympiad");
				alert.showAndWait();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {

			Alert alert = new Alert(Alert.AlertType.ERROR);

			alert.setTitle("Invalid Input");
			alert.setHeaderText("Error");
			alert.setContentText("Invalid Input Provided");
			alert.showAndWait();

		}
	}

	ObservableList<Olympiad> getOlympiads() {
		ObservableList<Olympiad> result = FXCollections.observableArrayList();

		try {
			User user = Main.getCurrentUser();
			Connection connection = new DBConnect().connect();
			String sql = "SELECT olympiad_olympiad.*, CASE WHEN olympiad_reg.student_id IS NOT NULL THEN 'YES' ELSE 'NO' END AS registered FROM olympiad_olympiad LEFT OUTER JOIN olympiad_reg ON olympiad_olympiad.id = olympiad_reg.olympiad_id AND olympiad_reg.student_id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, user.getID());
			ResultSet resultSet = preparedStatement.executeQuery();

			// Process the ResultSet and add data to the ObservableList
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				float price = resultSet.getFloat("price");
				LocalDate examDate = resultSet.getDate("exam_date").toLocalDate();
				LocalDate deadlineDate = resultSet.getDate("deadline_date").toLocalDate();

				// Create Olympiad object and add it to the ObservableList
				Olympiad olympiad = new Olympiad(id, name, price, examDate, deadlineDate);
				olympiad.setRegistered (resultSet.getString ("registered"));
				result.add(olympiad);
			}

		} catch (SQLException se) {
			se.printStackTrace();
			return result;
		}

		return result;
	}

	public void initialize() {
		// Configure columns with cell value factories

		IDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
		OlympiadNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
		PriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
		ExamDateColumn.setCellValueFactory(new PropertyValueFactory<>("examDate"));
		DeadlineColumn.setCellValueFactory(new PropertyValueFactory<>("deadlineDate"));
		RegisteredColumn.setCellValueFactory(new PropertyValueFactory<>("registered"));
		// Load data into the TableView
		ObservableList<Olympiad> data = getOlympiads();

		table.setItems(data);
	}
}