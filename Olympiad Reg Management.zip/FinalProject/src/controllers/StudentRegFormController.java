package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.DBConnect;

public class StudentRegFormController {

	@FXML
	private Button btnback;

	@FXML
	private Button btnclear;

	@FXML
	private Button btnregister;

	@FXML
	private TextField txtCity;

	@FXML
	private DatePicker txtDate;

	@FXML
	private TextField txtEmail;

	@FXML
	private TextField txtGrade;

	@FXML
	private TextField txtGuardianName;

	@FXML
	private TextField txtName;

	@FXML
	private PasswordField txtPassword;

	@FXML
	private TextField txtPhone;

	@FXML
	private TextField txtPincode;

	@FXML
	private TextField txtSchoolName;

	@FXML
	private TextField txtState;

	@FXML
	private TextField txtUsername;

	@FXML
	private AnchorPane mainPane;

	public void setMainPane(AnchorPane mainPane) {
		this.mainPane = (AnchorPane) mainPane;
	}

	@FXML
	void Back(ActionEvent event) {
		// Handle going back to the previous screen (StudentLogin.fxml)
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/StudentLogin.fxml"));
			Parent root = loader.load();

			// Access the StudentLoginController if needed to pass any stage or data

			Scene scene = new Scene(root);
			Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			currentStage.setScene(scene);
			currentStage.setTitle("Student Login");
			currentStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void Clear(ActionEvent event) {
		// Clear form fields
		txtName.clear();
		txtEmail.clear();
		txtUsername.clear();
		txtPassword.clear();
		txtCity.clear();
		txtState.clear();
		txtPincode.clear();
		txtPhone.clear();
		txtDate.getEditor().clear();
		txtGrade.clear();
		txtGuardianName.clear();
		txtSchoolName.clear();
	}

	@FXML
	private void Register(ActionEvent event) {
		if (verifyUserExist()) {
			showAlert(" Alert", "Student Already Exist");
		} else {
			createUser();
			
		}
	}

	private boolean verifyUserExist() {
		if (anyFieldIsEmpty()) {
			setRedBorderForEmptyFields();
		} else {
			try {
				DBConnect conn = new DBConnect();
				Connection connection = conn.connect();

				String sql = "SELECT * FROM olympiad_student Where Username = ?";
				PreparedStatement preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

				preparedStatement.setString(1, txtUsername.getText());
				
				ResultSet resultSet = preparedStatement.executeQuery();
				boolean result= resultSet.last();
				preparedStatement.close();
				connection.close();
				return result;

				
			} catch (SQLException e) {
				e.printStackTrace();
				return true; 
			}
		}
		return false;
	}

	private void createUser() {
		if (anyFieldIsEmpty()) {
			setRedBorderForEmptyFields();
		} else {
			try {
				DBConnect conn = new DBConnect();
				Connection connection = conn.connect();

				String sql = "INSERT INTO olympiad_student (Name, Email, Username, Password, Phone, Grade, DOB, School, Guardian, State, City, Pincode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
				PreparedStatement preparedStatement = connection.prepareStatement(sql);

				preparedStatement.setString(1, txtName.getText());
				preparedStatement.setString(2, txtEmail.getText());
				preparedStatement.setString(3, txtUsername.getText());
				preparedStatement.setString(4, txtPassword.getText());
				preparedStatement.setString(5, txtPhone.getText());
				preparedStatement.setString(6, txtGrade.getText());

				// Convert DatePicker value to the required format (YYYY-MM-DD)
				String formattedDate = txtDate.getValue().toString();

				preparedStatement.setString(7, formattedDate);
				preparedStatement.setString(8, txtSchoolName.getText());
				preparedStatement.setString(9, txtGuardianName.getText());
				preparedStatement.setString(10, txtState.getText());
				preparedStatement.setString(11, txtCity.getText());
				preparedStatement.setString(12, txtPincode.getText());

				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected > 0) {
					showAlert("Success", "Student Registered Successfully!");
				} else {
					showAlert("Error", "Failed to register the student. Please try again.");
					// Handle the failure scenario, if needed
				}

				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private void showAlert(String title, String message) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();
		// If registration was successful, navigate to StudentLogin.fxml
	    if (title.equals("Success")) {
	        try {
	            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/StudentLogin.fxml"));
	            Parent root = loader.load();

	            Scene scene = new Scene(root);
	            Stage currentStage = (Stage) mainPane.getScene().getWindow();
	            currentStage.setScene(scene);
	            currentStage.setTitle("Student Login");
	            currentStage.show();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}

	private boolean anyFieldIsEmpty() {
		return txtName.getText().isEmpty() || txtEmail.getText().isEmpty() || txtUsername.getText().isEmpty()
				|| txtPassword.getText().isEmpty() || txtCity.getText().isEmpty() || txtState.getText().isEmpty()
				|| txtPincode.getText().isEmpty() || txtPhone.getText().isEmpty()
				|| txtDate.getEditor().getText().isEmpty() || txtGrade.getText().isEmpty()
				|| txtGuardianName.getText().isEmpty() || txtSchoolName.getText().isEmpty();
	}

	private void setRedBorderForEmptyFields() {
		if (txtName.getText().isEmpty()) {
			txtName.setStyle("-fx-border-color: red;");
		}
		if (txtEmail.getText().isEmpty()) {
			txtEmail.setStyle("-fx-border-color: red;");
		}
		if (txtUsername.getText().isEmpty()) {
			txtUsername.setStyle("-fx-border-color: red;");
		}
		if (txtPassword.getText().isEmpty()) {
			txtPassword.setStyle("-fx-border-color: red;");
		}
		if (txtEmail.getText().isEmpty()) {
			txtEmail.setStyle("-fx-border-color: red;");
		}
		if (txtCity.getText().isEmpty()) {
			txtCity.setStyle("-fx-border-color: red;");
		}
		if (txtState.getText().isEmpty()) {
			txtState.setStyle("-fx-border-color: red;");
		}
		if (txtPincode.getText().isEmpty()) {
			txtPincode.setStyle("-fx-border-color: red;");
		}
		if (txtDate.getEditor().getText().isEmpty()) {
			txtDate.setStyle("-fx-border-color: red;");
		}
		if (txtPhone.getText().isEmpty()) {
			txtPhone.setStyle("-fx-border-color: red;");
		}
		if (txtGrade.getText().isEmpty()) {
			txtGrade.setStyle("-fx-border-color: red;");
		}
		if (txtGuardianName.getText().isEmpty()) {
			txtGuardianName.setStyle("-fx-border-color: red;");
		}
		if (txtSchoolName.getText().isEmpty()) {
			txtSchoolName.setStyle("-fx-border-color: red;");
		}
	}
}
