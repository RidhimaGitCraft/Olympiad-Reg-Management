package controllers;

import java.io.IOException;
import java.util.Optional;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Effect;

public class AdminHomeController {

    @FXML
    private ImageView LogoutIcon;

    @FXML
    private ImageView ProductIcon;

    @FXML
    private ImageView StudentIcon;

    @FXML
    private AnchorPane mainPane;
    

    
    @FXML
    void handleProductIconClick(MouseEvent event) {
        if (event.getSource() == ProductIcon) {
            loadFXML("/view/AdminHomeProduct.fxml");
            
        }
    }

    @FXML
    private void handleStudentIconClick(MouseEvent event) {
        if (event.getSource() == StudentIcon) {
            loadFXML("/view/ManageStudentReg.fxml");
        }
    }

    @FXML
    private void handleLogoutIconClick(MouseEvent event) {
    	Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) mainPane.getScene().getWindow();
            stage.close();
        }   
    }

    @FXML
   private void handleHover(MouseEvent event) {
        if (event.getSource() instanceof ImageView) {
            ImageView imageView = (ImageView) event.getSource();
            addHoverEffect(imageView);
        }
    }

    @FXML
  private  void handleHoverExit(MouseEvent event) {
        if (event.getSource() instanceof ImageView) {
            ImageView imageView = (ImageView) event.getSource();
            removeHoverEffect(imageView);
        }
    }

    private void loadFXML(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent pane = loader.load();
            mainPane.getChildren().setAll(pane);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addHoverEffect(ImageView imageView) {
        Effect effect = new DropShadow(); // You can adjust the effect parameters here
        imageView.setEffect(effect);
    }

    private void removeHoverEffect(ImageView imageView) {
        imageView.setEffect(null);
    }
}
