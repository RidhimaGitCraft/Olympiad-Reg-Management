package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.DBConnect;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import models.Olympiad;

public class ManageOlympiadController {

    @FXML
    private Button btnback;

    @FXML
    private Button btnupdate;

    @FXML
    private Pane mainPane;

    @FXML
    private DatePicker txtdeadline;

    @FXML
    private DatePicker txtexamdate;

    @FXML
    private TextField txtolympiadname;

    @FXML
    private TextField txtprice;

    @FXML
    void Back(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/adminhomeproduct.fxml"));
            Parent adminHomeProduct = loader.load();

            // Access the controller of the AdminHomeProductController if needed
            // AdminHomeProductController adminHomeProductController = loader.getController();
            // adminHomeProductController.initialize(); // If you have an initialize method

            Scene scene = new Scene(adminHomeProduct);
            Stage stage = (Stage) mainPane.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Admin Home Product");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void Update(ActionEvent event) {
        try {
            DBConnect conn = new DBConnect();
            Connection connection = conn.connect();

            String sql = "UPDATE olympiad_olympiad SET name = ?, price = ?, exam_date = ?, deadline_date = ? WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Set updated values from the UI components
            preparedStatement.setString(1, txtolympiadname.getText());
            preparedStatement.setFloat(2, Float.parseFloat(txtprice.getText()));
            preparedStatement.setString(3, txtexamdate.getValue().toString()); // Assuming it's a String in your database
            preparedStatement.setString(4, txtdeadline.getValue().toString()); // Assuming it's a String in your database
            preparedStatement.setInt(5, selectedOlympiad.getId()); // Use the ID of the selected Olympiad

            // Execute update
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Update successful!");
            } else {
                System.out.println("Update failed!");
            }

            // Close resources
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private Olympiad selectedOlympiad; // Declare it at class level

    public void setOlympiad(Olympiad selectedOlympiad) {
        this.selectedOlympiad = selectedOlympiad;
        if (selectedOlympiad != null) {
            txtolympiadname.setText(selectedOlympiad.getName());
            txtprice.setText(String.valueOf(selectedOlympiad.getPrice()));
            txtexamdate.setValue(selectedOlympiad.getExamDate());
            txtdeadline.setValue(selectedOlympiad.getDeadlineDate());
        }
    }

}



