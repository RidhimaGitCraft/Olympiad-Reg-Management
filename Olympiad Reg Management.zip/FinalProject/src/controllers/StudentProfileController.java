package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import application.Main;
import dao.DBConnect;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import models.User;

public class StudentProfileController {

	@FXML
	private Button btnback;

	@FXML
	private Button btnclear;

	@FXML
	private Button btnmodify;

	@FXML
	private TextField txtCity;

	@FXML
	private TextField txtEmail;

	@FXML
	private TextField txtGrade;

	@FXML
	private TextField txtSchoolName;

	@FXML
	private TextField txtName;

	@FXML
	private TextField txtPassword;

	@FXML
	private TextField txtPhone;

	@FXML
	private TextField txtPincode;

	@FXML
	private TextField txtState;

	@FXML
	private TextField txtGuardian;

	@FXML
	private AnchorPane mainPane;

	public void setMainPane(AnchorPane mainPane) {
		this.mainPane = (AnchorPane) mainPane;
	}

	@FXML
	void Back(ActionEvent event) {
		// Handle going back to the previous screen (AdminLogin.fxml)
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/StudentPortal.fxml"));
			Parent root = loader.load();

			// Access the AdminLoginController if needed to pass any stage or data

			Scene scene = new Scene(root);
			Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			currentStage.setScene(scene);
			currentStage.setTitle("Student Portal");
			currentStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void Clear(ActionEvent event) {
		// Clear all text fields
		txtCity.clear();
		txtEmail.clear();
		txtGrade.clear();
		txtSchoolName.clear();
		txtName.clear();
		txtPassword.clear();
		txtPhone.clear();
		txtPincode.clear();
		txtState.clear();
		txtGuardian.clear();
	}

	@FXML
	void Modify(ActionEvent event) {
		User user = Main.getCurrentUser();
		// Implement modification logic here
		// Fetch data from text fields and modify student data
		try {
			Connection connection = new DBConnect().connect();
			String sql = "Update olympiad_student set Name=? , Email=?, City=?, Password=?, Phone=?, Pincode=?, Grade=?, State=?, School=?, Guardian = ? where student_id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, txtName.getText());
			preparedStatement.setString(2, txtEmail.getText());
			preparedStatement.setString(3, txtCity.getText());
			preparedStatement.setString(4, txtPassword.getText());
			preparedStatement.setString(5, txtPhone.getText());
			preparedStatement.setString(6, txtPincode.getText());
			preparedStatement.setString(7, txtGrade.getText());
			preparedStatement.setString(8, txtState.getText());
			preparedStatement.setString(9, txtSchoolName.getText());
			preparedStatement.setString(10, txtGuardian.getText());
			preparedStatement.setInt(11, user.getID());

			preparedStatement.executeUpdate();
            
			Alert alert = new Alert(Alert.AlertType.CONFIRMATION);

			alert.setTitle("Update Success");
			alert.setHeaderText("Success");
			alert.setContentText("Profile Updated Successfully");
			alert.showAndWait();
			initialize();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void initialize() {
		User user = Main.getCurrentUser();
		user.refreshUser(user.getUsername());
		txtName.setText(user.getName());
		txtEmail.setText(user.getEmail());
		txtGuardian.setText(user.getGuardian());
		txtPassword.setText(user.getPassword());
		txtPhone.setText(user.getPhone());
		txtGrade.setText(String.valueOf(user.getGrade()));
		txtCity.setText(user.getCity());
		txtState.setText(user.getState());
		txtPincode.setText(user.getPincode());
	//	txtGuardianName.setText(user.getGuardian());
		txtSchoolName.setText(user.getSchool());

	}
}