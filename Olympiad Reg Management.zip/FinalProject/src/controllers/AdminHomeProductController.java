package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Olympiad;
import models.User;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import application.Main;
import dao.DBConnect;

public class AdminHomeProductController {
	@FXML
	private TableColumn<Olympiad, Integer> IDColumn;

	@FXML
	private TableColumn<Olympiad, String> OlympiadNameColumn;

	@FXML
	private TableColumn<Olympiad, Float> PriceColumn;

	@FXML
	private TableColumn<Olympiad, LocalDate> ExamDateColumn;

	@FXML
	private TableColumn<Olympiad, LocalDate> DeadlineColumn;

	@FXML
	private Button btnedit;

	@FXML
	private Button btnback;

	@FXML
	private AnchorPane mainPane;

	@FXML
	private TableView<Olympiad> table;

	@FXML
	private TextField txtOlympiad;

	@FXML
	void Edit(ActionEvent event) {
	    // Get the ID from the text field
	    int selectedID = Integer.parseInt(txtOlympiad.getText());

	    // Iterate through the table items to find the matching ID
	    for (Olympiad olympiad : table.getItems()) {
	        if (olympiad.getId() == selectedID) {
	            table.getSelectionModel().select(olympiad);
	            table.scrollTo(olympiad); // Scroll to the selected item
	            
	            try {
	                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/ManageOlympiad.fxml"));
	                Parent manageOlympiad = loader.load();
	                ManageOlympiadController controller = loader.getController();

	                controller.setOlympiad(olympiad);
	                mainPane.getChildren().setAll(manageOlympiad);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }

	            return; // Exit the loop after selecting the item
	        }
	    }

	    // If no match is found
	    System.out.println("No Olympiad found with ID: " + selectedID);
	}
	
	@FXML
	void Back() {
		try {
			Parent adminHome = FXMLLoader.load(getClass().getResource("/view/AdminHome.fxml"));
			if (adminHome != null && mainPane != null) {
				mainPane.getChildren().setAll(adminHome);
				Stage stage = (Stage) mainPane.getScene().getWindow();
				if (stage != null) {
					stage.setTitle("Admin Home");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private ObservableList<Olympiad> getOlympiads() {
		ObservableList<Olympiad> result = FXCollections.observableArrayList();

		try {
			User user = Main.getCurrentUser();
			Connection connection = new DBConnect().connect();
			String sql = "SELECT olympiad_olympiad.*, CASE WHEN olympiad_reg.student_id IS NOT NULL THEN 'YES' ELSE 'NO' END AS registered FROM olympiad_olympiad LEFT OUTER JOIN olympiad_reg ON olympiad_olympiad.id = olympiad_reg.olympiad_id AND olympiad_reg.student_id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, user.getID());
			ResultSet resultSet = preparedStatement.executeQuery();

			// Process the ResultSet and add data to the ObservableList
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				float price = resultSet.getFloat("price");
				LocalDate examDate = resultSet.getDate("exam_date").toLocalDate();
				LocalDate deadlineDate = resultSet.getDate("deadline_date").toLocalDate();

				// Create Olympiad object and add it to the ObservableList
				Olympiad olympiad = new Olympiad(id, name, price, examDate, deadlineDate);
				olympiad.setRegistered(resultSet.getString("registered"));
				result.add(olympiad);
			}

		} catch (SQLException se) {
			se.printStackTrace();
		}

		return result;
	}

	@FXML
	private void initialize() {
		// Configure columns with cell value factories (assuming appropriate Olympiad
		// properties)
		IDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
		OlympiadNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
		PriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
		ExamDateColumn.setCellValueFactory(new PropertyValueFactory<>("examDate"));
		DeadlineColumn.setCellValueFactory(new PropertyValueFactory<>("deadlineDate"));

		// Fetch and load data into the TableView
		ObservableList<Olympiad> data = getOlympiads();
		if (data != null) {
			table.setItems(data);
		} else {
			System.out.println("No Olympiad data available.");
		}
	}
}