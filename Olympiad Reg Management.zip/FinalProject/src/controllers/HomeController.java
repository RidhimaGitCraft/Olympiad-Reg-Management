package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Effect;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class HomeController {

    @FXML
    private ImageView adminIcon;

    @FXML
    private ImageView studentIcon;

    @FXML
    private ImageView LogoutIcon;

    @FXML
    private AnchorPane mainPane;


    @FXML
    void goToAdminLogin(MouseEvent event) {
        loadAndSetTitle("/view/AdminLogin.fxml", "Admin Login");
    }

    @FXML
    private void goToStudentPage(MouseEvent event) {
        loadAndSetTitle("/view/StudentLogin.fxml", "Student Login");
    }

    @FXML
    private void closeWindow(MouseEvent event) {
    	Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Logout Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to logout?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) mainPane.getScene().getWindow();
            stage.close();
        }   
    }

    @FXML
    private void handleHover(MouseEvent event) {
        if (event.getSource() instanceof ImageView) {
            ImageView imageView = (ImageView) event.getSource();
            addHoverEffect(imageView);
        }
    }

    @FXML
    private void handleHoverExit(MouseEvent event) {
        if (event.getSource() instanceof ImageView) {
            ImageView imageView = (ImageView) event.getSource();
            removeHoverEffect(imageView);
        }
    }

    private void loadAndSetTitle(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent page = loader.load();

            Stage stage = new Stage();
            stage.setTitle(title); // Set the title for the stage

            stage.setScene(new Scene(page));
            stage.show();

            Stage currentStage = (Stage) mainPane.getScene().getWindow();
            currentStage.close(); // Close the home window when opening Admin or Student login
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addHoverEffect(ImageView imageView) {
        Effect effect = new DropShadow(); // You can adjust the effect parameters here
        imageView.setEffect(effect);
    }

    private void removeHoverEffect(ImageView imageView) {
        imageView.setEffect(null);
    }
}
