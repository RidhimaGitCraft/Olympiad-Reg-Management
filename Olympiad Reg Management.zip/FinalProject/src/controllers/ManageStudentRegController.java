package controllers;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import application.Main;
import dao.DBConnect;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import models.Olympiad;
import models.OlympiadStudent;
import models.User;

public class ManageStudentRegController {

	@FXML
	private TableColumn<OlympiadStudent, Integer> GradeColumn;

	@FXML
	private TableColumn<OlympiadStudent, Integer> IDColumn;

	@FXML
	private TableColumn<OlympiadStudent, String> NameColumn;

	@FXML
	private TableColumn<OlympiadStudent, String> OlympiadNameColumn;

	@FXML
	private Button btnback;

	@FXML
	private Button btndelete;

	@FXML
	private AnchorPane mainPane;

	@FXML
	private TextField studentolympiad;

	@FXML
	private TableView<OlympiadStudent> table;

	@FXML
	void Back(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AdminHome.fxml"));
			Parent adminHome = loader.load();
			Stage stage = (Stage) btnback.getScene().getWindow();
			Scene scene = new Scene(adminHome);
			stage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void Delete(ActionEvent event) {
		// Get the ID from the text field
		int selectedID = Integer.parseInt(studentolympiad.getText());
		try {
			Connection connection = new DBConnect().connect();
			String sql = "DELETE FROM olympiad_reg WHERE id = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, selectedID);

		     preparedStatement.executeUpdate();
		     Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
				alert.setTitle("Data Deleted");
				alert.setHeaderText("Delete");
				alert.setContentText("Student Data Deleted!");
				alert.showAndWait();
				initialize();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	@FXML
	void initialize() {
		IDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
		NameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
		GradeColumn.setCellValueFactory(new PropertyValueFactory<>("grade"));
		OlympiadNameColumn.setCellValueFactory(new PropertyValueFactory<>("olympiad"));

		// Fetch and load data into the TableView
		ObservableList<OlympiadStudent> data = getOlympiadStudentData();
		if (data != null) {
			table.setItems(data);
		}
	}

	private ObservableList<OlympiadStudent> getOlympiadStudentData() {
		ObservableList<OlympiadStudent> result = FXCollections.observableArrayList();

		try {
			Connection connection = new DBConnect().connect();
			String sql = "select olympiad_reg.id as registration_id,olympiad_student.name as student_name,grade,olympiad_olympiad.name from olympiad_reg join olympiad_olympiad on olympiad_reg. olympiad_id = olympiad_olympiad.id join olympiad_student on olympiad_student.student_id = olympiad_reg.student_id";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();

			// Process the ResultSet and add data to the ObservableList
			while (resultSet.next()) {
				int id = resultSet.getInt("registration_id");
				String name = resultSet.getString("student_name");
				int grade = resultSet.getInt("Grade");
				String olympiadName = resultSet.getString("name");
				// Create OlympiadStudent objects and add them to the ObservableList
				OlympiadStudent student = new OlympiadStudent(id, name, grade, olympiadName);
				result.add(student);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
		return result;
	}

}
