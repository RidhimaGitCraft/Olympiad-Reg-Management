package controllers;

import application.Main;
import dao.DBConnect;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import models.User;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentLoginController {

    @FXML
    private Button btnBack;

    @FXML
    private Button btnSignin;

    @FXML
    private Button btnSignup;

    @FXML
    private ImageView imgstudent;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private TextField txtUsername;

    @FXML
    private void Back(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/Home.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Stage homeStage = (Stage) btnBack.getScene().getWindow();
            homeStage.setScene(scene);
            homeStage.setTitle("Home");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void SignIn(ActionEvent event) {
    	String username = txtUsername.getText();
        String password = txtPassword.getText();

        if (authenticateUser(username, password)) {
            openStudentPortal();
        } else {
            // Handle invalid login credentials
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Authentication Error");
            alert.setHeaderText(null);
            alert.setContentText("Invaild Credentials. Please try again.");
            alert.showAndWait();
        }
    }

    private void setCurrentUser(ResultSet resultSet) {
        User user = new User ();
        
        // Set data from the ResultSet to the User object
        try {
			user.setID(resultSet.getInt("student_id"));
			user.setName(resultSet.getString("Name"));
	        user.setEmail(resultSet.getString("Email"));
	        user.setUsername(resultSet.getString("Username"));
	        user.setPhone(resultSet.getString("Phone"));
	        user.setGrade(resultSet.getInt("Grade"));
	        user.setDob(resultSet.getDate("DOB").toLocalDate());
	        user.setSchool(resultSet.getString("School"));
	        user.setGuardian(resultSet.getString("Guardian"));
	        user.setCity(resultSet.getString("City"));
	        user.setPincode(resultSet.getString("Pincode"));
	        user.setPassword(resultSet.getString("Password"));
	        user.setState(resultSet.getString("State"));
	        Main.setCurrentUser(user);
	        
		} catch (SQLException e) {
			e.printStackTrace();
		}
        

    }

    private boolean authenticateUser(String username, String password) {
        try {
            Connection connection = new DBConnect().connect();
            String sql = "SELECT * FROM olympiad_student WHERE username = ? AND password = ? limit 1";
            PreparedStatement preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
            	
                setCurrentUser(resultSet);
                resultSet.previous();
            }

            return resultSet.next(); // Returns true if there's a matching record, false otherwise

        } catch (SQLException se) {
            se.printStackTrace();
            return false;
        }
    }

    @FXML
    void SignUp(ActionEvent event) {
        openStudentRegForm();
        closeStudentLoginWindow();
    }

    private void closeStudentLoginWindow() {
        Stage stage = (Stage) btnSignup.getScene().getWindow();
        stage.close();
    }
    public static void openStudentRegForm() {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/StudentRegForm.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Stage studentRegFormStage = new Stage();
            studentRegFormStage.setTitle("Student Registration Form");
            studentRegFormStage.setScene(scene);
            studentRegFormStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openStudentPortal() {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("/view/StudentPortal.fxml"));
            Parent root = loader.load();
            Scene scene = new Scene(root);

            Stage studentPortalStage = new Stage();
            studentPortalStage.setScene(scene);
            studentPortalStage.show();

            Stage currentStage = (Stage) btnSignin.getScene().getWindow();
            currentStage.close(); // Close the login window after successful login
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}