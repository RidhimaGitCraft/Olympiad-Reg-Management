package models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import dao.DBConnect;

public class OlympiadAdminLogin {
    DBConnect conn = null;
    
	  public OlympiadAdminLogin() {
	        conn = new DBConnect();
	    }

	    public void signIn(String username, String password) {
	        try {
	            String sql = "SELECT * FROM admin_olympiad WHERE username = ? AND password = ?";
	            PreparedStatement preparedStatement = conn.connect().prepareStatement(sql);
	            preparedStatement.setString(1, username);
	            preparedStatement.setString(2, password);

	            ResultSet resultSet = preparedStatement.executeQuery();

	            if (resultSet.next()) {
	                // Valid credentials, perform actions here (e.g., update the database)
	                // For example:
	                int userId = resultSet.getInt("user_id");
	                // Update a field to indicate the user has signed in
	                String updateQuery = "UPDATE admin_olympiad SET signed_in = 1 WHERE user_id = ?";
	                PreparedStatement updateStatement = conn.connect().prepareStatement(updateQuery);
	                updateStatement.setInt(1, userId);
	                updateStatement.executeUpdate();
	                updateStatement.close();
	            } else {
	                // Invalid credentials
	                System.out.println("Invalid credentials!");
	            }

	            resultSet.close();
	            preparedStatement.close();
	            conn.connect().close();

	        } catch (SQLException se) {
	            se.printStackTrace();
	        }
	    }
	}