package models;

import dao.DBConnect;

public class OlympiadReg {
    private DBConnect conn;

    public OlympiadReg() {
        conn = new DBConnect();
    }

}