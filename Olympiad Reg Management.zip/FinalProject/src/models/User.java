package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import application.Main;
import dao.DBConnect;

public class User {
	private int id;
	private String name;
	private String email;
	private String username;
	private String phone;
	private int grade;
	private LocalDate dob;
	private String school;
	private String guardian;
	private String city;
	private String pincode;
	private String password;
	private String state;

	// Default constructor for a guest user
	public User() {
		this.name = "Guest";
		// Set default values for other properties as needed...
	}

	// Getters and setters for each field

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getGuardian() {
		return guardian;
	}

	public void setGuardian(String guardian) {
		this.guardian = guardian;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void refreshUser(String username) {
		try {
			Connection connection = new DBConnect().connect();
			String sql = "SELECT * FROM olympiad_student WHERE username = ? limit 1";
			PreparedStatement preparedStatement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			preparedStatement.setString(1, username);

			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				this.setID(resultSet.getInt("student_id"));
				this.setName(resultSet.getString("Name"));
				this.setEmail(resultSet.getString("Email"));
				this.setUsername(resultSet.getString("Username"));
				this.setPhone(resultSet.getString("Phone"));
				this.setGrade(resultSet.getInt("Grade"));
				this.setDob(resultSet.getDate("DOB").toLocalDate());
				this.setSchool(resultSet.getString("School"));
				this.setGuardian(resultSet.getString("Guardian"));
				this.setCity(resultSet.getString("City"));
				this.setPincode(resultSet.getString("Pincode"));
				this.setPassword(resultSet.getString("Password"));
				this.setState(resultSet.getString("State"));
			}
		} catch (SQLException se) {
			se.printStackTrace();

		}
	}
}
