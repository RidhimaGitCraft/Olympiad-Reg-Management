package models;

import java.time.LocalDate;

public class Olympiad {
    private int id;
    private String name;
    private float price;
    private LocalDate examDate;
    private LocalDate deadlineDate;
    private String registered;
    public Olympiad(int id, String name, float price, LocalDate examDate, LocalDate deadlineDate) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.examDate = examDate;
        this.deadlineDate = deadlineDate;
    }

    // Getters and setters for each field (id, name, price, examDate, deadlineDate)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getRegistered() {
        return registered;
    }

    public void setRegistered(String registered) {
        this.registered = registered;
    }
    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public LocalDate getExamDate() {
        return examDate;
    }

    public void setExamDate(LocalDate examDate) {
        this.examDate = examDate;
    }

    public LocalDate getDeadlineDate() {
        return deadlineDate;
    }

    public void setDeadlineDate(LocalDate deadlineDate) {
        this.deadlineDate = deadlineDate;
    }
}
